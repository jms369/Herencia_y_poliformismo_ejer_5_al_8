package ejer_4_7;

public abstract class Animal {
    protected String sonido, alimentos, habitat, nombre_cientifico;


    public abstract String getSonido();
    public abstract String getAlimentos();
    public abstract String getHabitat();
    public abstract String getNombre_cientifico();
}
