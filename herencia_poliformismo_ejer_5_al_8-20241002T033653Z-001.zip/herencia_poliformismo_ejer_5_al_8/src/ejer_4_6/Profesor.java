package ejer_4_6;

public class Profesor {

    //Se cambio de "protected" a "public" para poder utilizar este metodo en el ejercicio "ejer_4_6_propuesto"//
    public void Imprimir(){
        System.out.println("es un profesor");
    }
}
