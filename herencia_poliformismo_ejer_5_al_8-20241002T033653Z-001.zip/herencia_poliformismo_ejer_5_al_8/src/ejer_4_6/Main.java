package ejer_4_6;

public class Main {
    public static void main(String[] args) {

        //no puede mostrar el metodo ImprimirAños cuando se utiliza "Profesor", se cambio a "ProfesorTitular" para solucionar el error//
        ProfesorTitular profesor1 = new ProfesorTitular();
        profesor1.ImprimirAños();
    }
}
