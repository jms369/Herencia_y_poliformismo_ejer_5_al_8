package ejer_4_7;

public abstract class Canido extends Animal{


}
