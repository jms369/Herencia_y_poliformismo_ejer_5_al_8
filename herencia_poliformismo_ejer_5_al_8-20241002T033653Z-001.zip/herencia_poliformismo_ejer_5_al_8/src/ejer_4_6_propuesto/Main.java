package ejer_4_6_propuesto;

import ejer_4_6.Profesor;
import ejer_4_6.ProfesorTitular;


import java.util.*;
public class Main {
    Vector profesores;
    public static void main(String[] args) {
        Main prueba = new Main();
        prueba.profesores = new Vector();
        Profesor profesor1 = new Profesor();
        ProfesorTitular profesor2 = new ProfesorTitular();
        prueba.profesores.add(profesor1);
        prueba.profesores.add(profesor2);
        for(int i = 0; i < prueba.profesores.size(); i++) {
            Profesor p = (Profesor) prueba.profesores.elementAt(i);
            p.Imprimir();
        }
    }
}

