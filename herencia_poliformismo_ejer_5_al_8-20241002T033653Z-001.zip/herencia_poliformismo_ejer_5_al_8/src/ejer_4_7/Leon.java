package ejer_4_7;

public class Leon extends Felino{

    public String getSonido(){
        return "Rugido";
    }
    public String getAlimentos() {
        return "Carnívoro";
    }
    public String getHabitat() {
        return "Praderas";
    }
    public String getNombre_cientifico() {
        return "Panthera leo";
    }
}
