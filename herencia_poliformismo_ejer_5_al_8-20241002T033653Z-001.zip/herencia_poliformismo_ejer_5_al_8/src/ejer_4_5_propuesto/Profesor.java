package ejer_4_5_propuesto;

public class Profesor {

    protected void imprimir(){
        System.out.println("Es un profesor");
    }
}
