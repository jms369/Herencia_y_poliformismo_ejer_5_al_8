package ejer_4_6;

public class ProfesorTitular extends Profesor{

    int años =0;

    public void Imprimir(){
        System.out.println("es un profesor titular");
    }

    protected void ImprimirAños(){
        System.out.println(" años= "+años);
    }
}
