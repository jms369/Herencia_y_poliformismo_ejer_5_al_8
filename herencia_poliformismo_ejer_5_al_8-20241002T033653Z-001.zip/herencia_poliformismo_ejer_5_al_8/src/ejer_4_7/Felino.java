package ejer_4_7;

public abstract class Felino extends Animal{

}
