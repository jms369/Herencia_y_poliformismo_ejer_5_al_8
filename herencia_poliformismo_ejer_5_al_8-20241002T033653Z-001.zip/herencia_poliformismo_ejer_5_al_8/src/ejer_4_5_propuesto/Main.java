package ejer_4_5_propuesto;


public class Main {
    public static void main(String[] args) {

        Profesor profesor1 = new ProfesorTitular();

        //sale error cuando se utiliza (Profesor), se tuvo que cambiar a (ProfesorTitular) para corregir el error//
        ProfesorTitular profesor2 = (ProfesorTitular) profesor1;
        profesor2.imprimir();
    }
}
