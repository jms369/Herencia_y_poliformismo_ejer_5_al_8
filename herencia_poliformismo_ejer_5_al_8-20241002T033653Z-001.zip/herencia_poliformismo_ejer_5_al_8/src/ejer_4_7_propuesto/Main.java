package ejer_4_7_propuesto;

public class Main {
    public static void main(String[] args) {

        Fraccion ob = new Fraccion(5,9);

        System.out.println("son los mismos números? "+ob.equals(ob));
        System.out.println(ob.toString());
    }
}
