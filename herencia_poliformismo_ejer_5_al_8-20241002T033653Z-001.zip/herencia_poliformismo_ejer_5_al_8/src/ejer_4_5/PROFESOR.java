package ejer_4_5;

public class PROFESOR {

    protected void Imprimir (){
        System.out.println("Es un profesor");

    }
}
