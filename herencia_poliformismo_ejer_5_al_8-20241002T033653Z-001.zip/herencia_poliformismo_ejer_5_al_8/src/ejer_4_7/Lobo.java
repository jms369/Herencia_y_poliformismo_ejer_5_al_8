package ejer_4_7;

public class Lobo extends Canido{

    public String getSonido(){
        return "Aullido";
    }
    public String getAlimentos() {
        return "Carnívoro";
    }
    public String getHabitat() {
        return "Bosque";
    }
    public String getNombre_cientifico() {
        return "Canis lupus";
    }
}
