package ejer_4_7_propuesto;

public class Fraccion extends Numerica{

    int numerador, denominador;

    public Fraccion(int numerador, int denominador){
        this.numerador = numerador;
        this.denominador = denominador;
    }


    @Override
    public String toString() {
        return numerador+"/"+denominador;
    }

    @Override
    public boolean equals(Object ob) {
        boolean a;
        if(this==ob) {

            a= true;
        }
        else{
            a=false;
        }
        return a;
    }


    @Override
    public Numerica sumar(Numerica sumar) {

        return sumar;
    }

    @Override
    public Numerica restar(Numerica restar) {
        return null;
    }

    @Override
    public Numerica multiplicar(Numerica multiplicar) {
        return null;
    }

    @Override
    public Numerica dividir(Numerica dividir) {
        return null;
    }
}
