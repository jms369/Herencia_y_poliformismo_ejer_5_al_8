package ejer_4_7_propuesto;

public abstract class Numerica {

    public abstract String toString();

    public abstract boolean equals(Object ob);

    public abstract Numerica sumar(Numerica sumar);

    public abstract Numerica restar(Numerica restar);

    public abstract Numerica multiplicar(Numerica multiplicar);

    public abstract Numerica dividir(Numerica dividir);

}
