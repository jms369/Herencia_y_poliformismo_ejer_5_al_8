package ejer_4_8_propuesto;

public abstract class Figura_Geometrica {


    public abstract double Area();
    public abstract double Perimetro();

}
