package ejer_4_7;

public class Gato extends Felino{

    public String getSonido(){
        return "Maullido";
    }
    public String getAlimentos() {
        return "Ratones";
    }
    public String getHabitat() {
        return "Doméstico";
    }
    public String getNombre_cientifico() {
        return "Felis silvestris catus";
    }
}
