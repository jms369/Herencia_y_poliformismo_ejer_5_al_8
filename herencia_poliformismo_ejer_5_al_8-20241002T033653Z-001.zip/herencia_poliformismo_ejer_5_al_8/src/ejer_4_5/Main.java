package ejer_4_5;

public class Main {
    public static void main(String[] args) {

        PROFESOR_TITULAR obj = new PROFESOR_TITULAR();
        obj.Imprimir();
    }
}
