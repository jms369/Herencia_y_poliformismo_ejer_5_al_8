package ejer_4_5;

public class PROFESOR_TITULAR extends PROFESOR{

    protected void Imprimir(){
        System.out.println("Es un profesor titular");
    }
}
