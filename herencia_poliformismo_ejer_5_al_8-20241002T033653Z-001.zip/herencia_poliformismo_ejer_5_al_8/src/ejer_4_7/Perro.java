package ejer_4_7;

public class Perro extends Canido{

    public String getSonido(){
        return "ladrido";
    }
    public String getAlimentos() {
        return "Carnívoro";
    }
    public String getHabitat() {
        return "Doméstico";
    }
    public String getNombre_cientifico() {
        return "Canis lupus familiaris";
    }

    }
