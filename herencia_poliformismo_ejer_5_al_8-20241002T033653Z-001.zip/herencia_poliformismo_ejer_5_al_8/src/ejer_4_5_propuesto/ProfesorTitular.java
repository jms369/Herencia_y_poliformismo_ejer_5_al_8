package ejer_4_5_propuesto;

public class ProfesorTitular extends Profesor{

    protected void imprimir(){
        System.out.println("Es un profesor titular");
    }
}
